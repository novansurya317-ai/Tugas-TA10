import utils

def input_data_mahasiswa():
    data_mahasiswa = []
    print("Masukkan data mahasiswa (ketik 'selesai' untuk berhenti):")
    
    while True:
        nama = input("Nama Mahasiswa: ")
        if nama.lower() == 'selesai':
            break
        
        while True:
            try:
                nilai = float(input(f"Nilai {nama}: "))
                break
            except ValueError:
                print("Nilai harus berupa angka. Silakan coba lagi.")
                
        data_mahasiswa.append((nama, nilai))
        print(f"Data{nama} dengan nilai {nilai} telah ditambahkan.\n")
    return data_mahasiswa

def cetak_tabel_rekap(data_mahasiswa):
    
    if len(data_mahasiswa) == 0:
        print("Tidak ada data mahasiswa untuk ditampilkan.")
        return

    print("\n" + "=" * 60)
    print("Rekap Nilai Mahasiswa")
    print("=" * 60)

    #Header Tabel
    print("No. | Nama Mahasiswa       | Nilai")
    print("-" * 60)

    #Tampilkan data per mahasiswa
    for i, (nama, nilai) in enumerate(data_mahasiswa, 1):
        print(f"{i:<4}| {nama:<20} | {nilai:>5}")
        
    print("-" * 60)
    
    nilai_saja = []
    for nama, nilai in data_mahasiswa:
        nilai_saja.append(nilai)
    
    # Gunakan fungsi dari utils.py
    rata_rata_kelas = utils.rata2(nilai_saja)
    status_kelas = utils.status_lulus(rata_rata_kelas)
    nama_tertinggi, nilai_tertinggi = utils.cari_tertinggi(data_mahasiswa)
    
    # Tampilkan statistik
    print(f"Jumlah Mahasiswa : {len(data_mahasiswa)}")
    print(f"Rata-rata Kelas  : {rata_rata_kelas:.2f}")
    print(f"Status Kelas     : {status_kelas}")
    print(f"Nilai Tertinggi  : {nilai_tertinggi:.2f} ({nama_tertinggi})")
    print("=" * 60)
    
def main():
    print("SELAMAT DATANG DI SISTEM PENGOLAHAN NILAI MAHASISWA")
    print()
    
    # Input data
    data = input_data_mahasiswa()
    
    # Cetak rekap
    cetak_tabel_rekap(data)
    
    # Tanya apakah ingin mengulang
    while True:
        ulang = input("\nApakah ingin input data lagi? (ya/tidak): ").lower()
        if ulang == 'ya':
            data_baru = input_data_mahasiswa()
            # Gabungkan dengan data sebelumnya
            data.extend(data_baru)
            cetak_tabel_rekap(data)
        elif ulang == 'tidak':
            print("Terima kasih telah menggunakan program ini!")
            break
        else:
            print("Pilihan tidak valid. Ketik 'ya' atau 'tidak'.")

# JALANKAN PROGRAM
if __name__ == "__main__":
    main()