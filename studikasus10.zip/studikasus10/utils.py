def rata2(data_list):
    if len(data_list) == 0:
        return 0
    
    total = 0
    for nilai in data_list:
        total = total + nilai
        
    rata_rata = total / len(data_list)
    return rata_rata

def status_lulus(rata_rata, batas_lulus = 75):
    if rata_rata >= batas_lulus:
        return "Lulus"
    else:
        return "Tidak Lulus"
    
def cari_tertinggi(data_mahasiswa):
    if len(data_mahasiswa) == 0:
        return None, 0
    nama_tertinggi = data_mahasiswa [0][0]
    nilai_tertinggi = data_mahasiswa [0][1]
    for nama, nilai in data_mahasiswa:
        if nilai > nilai_tertinggi:
            nama_tertinggi = nama
            nilai_tertinggi = nilai
            
    return nama_tertinggi, nilai_tertinggi
