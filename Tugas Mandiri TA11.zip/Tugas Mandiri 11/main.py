import Fungsi_Volume_Balok
import volume_bola
import Luas_Lingkaran
import keliling_lingkaran

def main():
    print("Menghitung Volume Balok")
    
    panjang = float(input("Masukan Panjang Balok:"))
    lebar = float(input("Masukan Lebar Balok:"))
    tinggi = float(input("Masukan Tinggi Balok:"))
    
    volume = Fungsi_Volume_Balok.volume_balok(panjang, lebar, tinggi)
    
    print(f"Volume dengan panjang {panjang}, lebar {lebar}, dan tinggi {tinggi} adalah {volume:.2f} cm^3")
    
    print("Menghitung Volume Bola")
    jari_jari_bola = float(input("Masukan Jari-jari Bola:"))
    
    volume = volume_bola.volume_bola(jari_jari_bola)
    
    print(f"Volume Bola dengan jari-jari {jari_jari_bola} adalah {volume:.2f} cm^3")
    
    print("Menghitung Luas Lingkaran")
    jari_jari_lingkaran = float(input("Masukan Jari-jari Lingkaran:"))
    
    luas = Luas_Lingkaran.luas_lingkaran(jari_jari_lingkaran)
    
    print(f"Luas Lingkaran dengan jari-jari {jari_jari_lingkaran} adalah {luas:.2f} cm^2")
    
    print("Menghitung Keliling Lingkaran")
    jari_jari_keliling = float(input("Masukan Jari-jari Lingkaran:"))
    
    keliling = keliling_lingkaran.keliling_lingkaran(jari_jari_keliling)
    
    print(f"Keliling Lingkaran dengan jari-jari {jari_jari_keliling} adalah {keliling:.2f} cm")
    
if __name__ == "__main__":
    main()