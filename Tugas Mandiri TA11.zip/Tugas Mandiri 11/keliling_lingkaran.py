def keliling_lingkaran(jari_jari):
    phi=3.14
    return 2*phi*jari_jari