def luas_lingkaran(jari_jari):
    phi=3.14
    return phi*jari_jari*jari_jari