def volume_balok(panjang, lebar, tinggi):
    return panjang * lebar * tinggi