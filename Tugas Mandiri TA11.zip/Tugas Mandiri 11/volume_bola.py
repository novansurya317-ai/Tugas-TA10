def volume_bola(jari_jari):
    phi=3.14
    return (4/3)*phi*jari_jari**3